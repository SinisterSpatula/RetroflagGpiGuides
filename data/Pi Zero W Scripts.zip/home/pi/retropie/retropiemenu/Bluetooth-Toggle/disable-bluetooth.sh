#!/bin/bash

sudo rfkill block bluetooth
echo "bluetooth disabled..."
sleep 5s