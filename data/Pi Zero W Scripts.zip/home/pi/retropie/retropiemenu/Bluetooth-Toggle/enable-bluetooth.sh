#!/bin/bash

sudo rfkill unblock bluetooth
echo "bluetooth enabled..."
sleep 5s