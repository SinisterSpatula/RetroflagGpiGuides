#!/usr/bin/env bash
sudo shutdown -P now
