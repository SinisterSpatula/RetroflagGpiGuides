#!/bin/bash

sudo rfkill block wifi
echo "Wifi disabled..."
sleep 5s