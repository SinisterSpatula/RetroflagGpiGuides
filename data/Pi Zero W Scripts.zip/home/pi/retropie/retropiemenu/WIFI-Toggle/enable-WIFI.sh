#!/bin/bash

sudo rfkill unblock wifi
echo "Wifi enabled..."
sleep 5s