Install lr-mame2016.
Copy the roms to mame roms directory. /home/pi/RetroPie/roms/mame-libretro
Copy the nvram folders into the mame nvram directory. /home/pi/RetroPie/roms/mame-libretro/mame2016/nvram
That's all you need to do.  Then setup your controls in retroarch or via bluetooth keyboard (tab key).
Or use my lr-mame2016 cfg files which are provided.  They should go in: /home/pi/RetroPie/roms/mame-libretro/mame2016/cfg



Games:
pexm001p.zip - Player's Edge Plus (XM00001P+XMP00003) Multi-Poker
pexm004p.zip - Player's Edge Plus (XM00004P+XMP00002) Multi-Poker
pex0055p.zip - Player's Edge Plus (X000055P+XP000022) Deuces Wild Poker
pepp0816.zip - Player's Edge Plus (PP0816) Treasure Chest Poker

pebe0014.zip - Player's Edge Plus (BE0014) Blackjack

peke0001.zip - Player's Edge Plus (KE0001) Keno

peps0021.zip - Player's Edge Plus (PS0021) Red White&Blue Slots
peps0042.zip - Player's Edge Plus (PS0042) Double Diamond Slots
peps0296.zip - Player's Edge Plus (PS0296) Haywire Slots
peps0426.zip - Player's Edge Plus (PS0426) Sizzling Sevens Slots
peps0615.zip - Player's Edge Plus (PS0615) Chaos Slots
peps0716.zip - Player's Edge Plus (PS0716) River Gambler Slots

"Set Chips" (configuration chips)
peset001.zip - Player's Edge Plus (Set001) Set Chip - Not a game, but a "Set Chip"/configuration chip.
peset038.zip - Player's Edge Plus (Set038) Set Chip - Not a game, but a "Set Chip"/configuration chip.
Use these set chips to enable bill validator (insert bills, instead of coins).  I've already done this and provided ready to use nvram files for quick play without setup.

If you want to change settings about a machine, Press O to open the door.  Press K until you hear a beep, or for some machines just press and release.
Then tap K until you see the setup menu.  Press K to cycle to the next menu, press L (jackpot reset) to adjust a setting, Press Q (deal/spin) to move to the next setting
within a menu.  When you reach the end of the menus, press O to close the door, and press L (jackpot Reset).

How to use the set chips to enable bill validator:
Copy the nvram files of the machine into the nvramfiles of the setchip (overwrite them).
Boot the set chip.  Press Q (deal/spin) to enable/disable bill validator.  Press K (self test) to save the new eprom setting.  Exit the emulation.  Copy the nvram files from the setchip back to the nvram files of the machine. (overwrite).  Then boot the machine.  You will have to do a reset proceedure:
Press O to open the door, press K (self test), Press O to close the door.  Press L (jackpot reset).


Default Mame keyboard controls:
Keys:
L = Jackpot Reset
K = Self test
Z = hold 1
X = hold 2
C = hold 3
V = hold 4
B = hold 5
5 = coin in
6 = bill in
Q = Deal-Spin-Start
T = Cashout
Y = Change Request/call attendant
W = Max Bet
R = Play Credit
M = Card Cage
I = Lower Door
O = Upper Door

Press 6 to insert credits, Press W to Bet 5 credits, Press R to bet 1 credit


Mame 0.183 was the last version to have working bill validator.  As of 0.211 it is still not fixed.
lr-mame2016 is based on 0.174 so this works out fine.